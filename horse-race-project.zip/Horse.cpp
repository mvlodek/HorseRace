#include "Horse.h"
#include<iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

Horse::Horse(string riderName, string horseName) {
    jockey = riderName;
    horse = horseName;
    distanceTraveled = 0;
    // Calculate random maxRunningDistPerSecond using rand
    unsigned seed = time(0);
    // Seed random number generator
    srand(seed);
    maxRunningDistPerSecond = (rand() % 101) +1;
    racesWon = 0;
}
void Horse::runASecond() {
    distanceTraveled += maxRunningDistPerSecond;
}
void Horse::sendtoGate() {
    distanceTraveled = 0;
}

void Horse::displayHorse(int goalLength) {
    cout << "|";
    for (int i = 0; i < DISPLAY_DIST; i++) {
        if (i == (distanceTraveled * DISPLAY_DIST) / goalLength) {
            cout << ">";
        } else {
            cout << " ";
        }
    }
        cout << "|";

        if (distanceTraveled >= goalLength) {
            cout << ">";
        } else {
            cout << " ";
        }
        cout << " " << horse << ", ridden by " << jockey << endl;
    }

void Horse::win() {
    racesWon++;
}