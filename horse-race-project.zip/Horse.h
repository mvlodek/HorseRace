#include<string>
using namespace std;

#ifndef HORSE_H
#define HORSE_H
// Remember to use scope resolution operator

class Horse {
    private:
        static const int DISPLAY_DIST = 50; // displays horse race on one line
        string horse;
        string jockey;
        int maxRunningDistPerSecond;
        int distanceTraveled;
        int racesWon = 0;
    public:
        Horse(string, string);  // Constructor
        void runASecond();
        void sendtoGate();
        void displayHorse(int); // Displays horse race progress
        void win();

        string getName() const {
            return jockey;
        }
        int getDistanceTraveled() const {
            return distanceTraveled;
        };
        int getRacesWon() const {
            return racesWon;
        }
};
#endif