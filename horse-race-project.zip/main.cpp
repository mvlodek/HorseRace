#include "Horse.h"
#include <iostream>
#include <string>


using namespace std;

int main() {
    int numHorses, distance; // intialize variables
    string horseName;
    string rider;
    char again;

    cout << "How many horse are in the race: ";
    cin >> numHorses;
    // Input validation
    while(numHorses < 2) {
        cout << "Need at least 2 horses to run a race: ";
        cin >> numHorses;
    }
    
    // Dynamically allocate Horse objects
    Horse *horseArr[numHorses];
    // Clear input buffer
    cin.ignore();
     // Take in the horses and riders of each horse
    for(int i = 0; i < numHorses; i++) {
        cout << "Enter the name of horse " << i + 1 << ": ";
        getline(cin, horseName);
        cin.clear();
        cout << "Enter the name of rider " << i + 1 << ": ";
        getline(cin, rider);
        // Dynamically allocate array to
        horseArr[i] = new Horse(horseName, rider);
    }

    cout << "Enter a distance of race: ";
    cin >> distance;
    // Check that race distance is at least 100
    while(distance < 100) {
        cout << "Race distance needs to be at least 100.";
        cin >> distance;
    }

    int numRaces = 0;
    // Racing loop
    do {
        numRaces++;
        // This loop sends horses to gate and displays the horse race
        for (int i = 0; i < numHorses; i++) {
            horseArr[i]->sendtoGate();
        }
        // Start the race
        cout << "\nThe start!" << endl;
        for (int i = 0; i < numHorses; i++) {
            horseArr[i] -> sendtoGate();
            horseArr[i]->displayHorse(distance);
        }
        // Ask if user would like to continue race
        cout << "\nProceed to the next second?(y/n): ";
        cin.ignore();
        // Enter loop if user elects to play another second
        if (cin.get() == 'y' || cin.get() == 'Y') {
            bool horseWon = false;
            // loops through seconds of the race
            do {
                // define horse pointer
                Horse *h;
                for (int i = 0; i < numHorses; i++) {
                    h = horseArr[i];
                    // run a second for each horse in the array
                    h->runASecond();
                    // calculates distance traveled for each horse in race
                    h->getDistanceTraveled();

                    // checks if a horse crossed finish line
                    if (h->getDistanceTraveled() >= distance) {
                        horseWon = true;
                    }
                    // display horse on track
                    h->displayHorse(distance);

                }
                // breaks loop if horseWon
                if (horseWon) {
                    horseWon = false;
                    break;
                }
                // ask user if they want to run another second
                cout << "\nWould you like to run another second(y/n)? ";
                cin.ignore();
            } while (cin.get() == 'y');
        }

        int winnerIndex = 0;
        int maxDistance = 0;
        // define another horseptr
        Horse *hptr;
        // iterate through loop for all horses
        for (int i = 0; i < numHorses; i++) {
            hptr = horseArr[i];
            // test if the horse has traveled max distance
            if (hptr->getDistanceTraveled() > maxDistance) {
                maxDistance = hptr->getDistanceTraveled();
                winnerIndex = i;
            }
        }
        // check if there is a tie 
        int chooseWinner;
        for(int i =0; i < numHorses; i++) {
            if(horseArr[winnerIndex] -> getDistanceTraveled() == horseArr[i]-> getDistanceTraveled()) {
                chooseWinner = rand() % 2;
                
                if(chooseWinner == 0) {
                    winnerIndex = i;
                }
            } 
        }

        horseArr[winnerIndex]->win();
        //display race
        for (int i = 0; i < numHorses; i++) {
            cout << horseArr[i]->getName() << " has won " << 
                horseArr[i]->getRacesWon() << "/" << numRaces << " races."
                    << endl;
        }
        // see if user wants to race again
        cout << "Do you want to continue(y/n)? ";
        cin.ignore();
    }while(cin.get() == 'y');

    //free dynamic memory
    for(int i = 0; i < numHorses; i++) {
        delete horseArr[i];
    }

    return 0;
}
